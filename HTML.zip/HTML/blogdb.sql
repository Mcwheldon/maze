-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 07, 2018 at 07:33 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(1, 'Business', '2018-02-20 19:43:47'),
(2, 'Technology', '2018-02-20 19:43:47'),
(5, 'Agricultutre', '2018-02-28 03:23:22'),
(6, 'Medicine', '2018-03-04 06:48:19');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `name` varchar(2552) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `name`, `email`, `body`, `created_at`) VALUES
(1, 11, 'mark', 'mark@mail.com', 'uh8j0kkojkokhghijo', '2018-02-25 11:14:13'),
(2, 11, 'nunu', 'mark@strath', 'This is my nunu', '2018-02-25 12:17:16'),
(3, 11, 'Wheldon', 'mgori089@gmail.com', 'This is a nice post...', '2018-02-25 17:35:25'),
(4, 13, 'Rael', 'Rael@mail.com', 'This is my comment', '2018-02-28 05:04:12'),
(5, 12, 'Mark', 'mark@strath', 'Shit I cannot edit this post', '2018-02-28 09:31:00'),
(6, 24, 'ff', 'ff@mail.com', 'Why can\'t I edit your post?', '2018-02-28 21:13:04'),
(7, 24, 'bn', 'bn@mail.com', 'Because you\'re not logged in as bn sucker', '2018-02-28 21:13:49'),
(8, 23, 'ff', 'ff@mail.com', 'Now I can edit or delete my post', '2018-02-28 21:19:26'),
(9, 26, 'bn', 'bn@mail.com', 'I can\'t post anything', '2018-03-01 05:31:46'),
(10, 26, 'ff', 'ff@mail.com', 'That should be by ff not bn since this is your post\r\n', '2018-03-01 06:52:01'),
(11, 24, 'Nash', 'nash@mail.com', 'Please stop using offensive words on this blog', '2018-03-02 08:24:46'),
(12, 30, 'nash', 'nash@mail.com', 'yeah....this is my first comment', '2018-03-06 06:56:52'),
(13, 30, 'nash', 'nash@mail.com', 'why the hell', '2018-03-06 07:04:37'),
(14, 30, 'nash', 'nash@mail.com', 'okay', '2018-03-06 07:05:23'),
(15, 32, 'bg', 'bgea@awsb.go.ke', 'why would you write a whole post about me', '2018-03-10 19:03:47'),
(16, 32, 'bn', 'bgea@mail.com', 'That\'s none of your business sucker', '2018-03-10 19:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `username` varchar(255) NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `title`, `slug`, `body`, `username`, `post_image`, `date`) VALUES
(66, 5, 'first post', 'first-post', '<p>first post with image</p>\r\n', 'bn', 'index.png', '2018-03-13 23:24:24'),
(67, 1, 'second', 'second', '<p>felis a sodales placerat, est metus aliquam ipsum, sit amet varius odio nibh vitae arcu. Ut accumsan fringilla leo non porttitor. Vivamus eget eleifend lectus. Curabitur est est, dictum vel feugiat pharetra, consequat laoreet tellus. Integer condimentum, velit pellentesque tincidunt rutrum, lectus massa dapibus sem, vel bibendum orci urna id dolor. Aenean aliquet justo vel aliquet efficitur. Cras quis faucibus odio. Suspendisse potenti. Phasellus mollis turpis vel eros rutrum, non efficitur ligula pellentesque. Etiam tempus diam augue, sit amet eleifend turpis cursus sed.</p>\r\n', 'nash', 'images.jpg', '2018-03-14 07:30:26'),
(73, 5, 'ggre', 'ggre', '<p>Vestibulum dictum orci justo. Pellentesque volutpat quis arcu eget ultricies. Vestibulum tempor massa nec mauris efficitur semper. Curabitur tincidunt interdum mattis. Maecenas eget pellentesque metus. Cras auctor mattis leo, nec consectetur dolor consequat in. Suspendisse mollis elit nisi, at imperdiet mauris pellentesque nec.</p>\r\n', 'nash', 'index.png', '2018-03-14 10:33:18'),
(74, 5, 'jhug', 'jhug', '<p>Pellentesque volutpat quis arcu eget ultricies. Vestibulum tempor massa nec mauris efficitur semper. Curabitur tincidunt interdum mattis. Maecenas eget pellentesque metus. Cras auctor mattis leo, nec consectetur dolor consequat in. Suspendisse mollis elit nisi, at imperdiet mauris pellentesque nec.</p>\r\n', 'nash', 'index.png', '2018-03-14 10:37:18'),
(79, 5, 'ggg', 'ggg', '<p>Pellentesque volutpat quis arcu eget ultricies. Vestibulum tempor massa nec mauris efficitur semper. Curabitur tincidunt interdum mattis. Maecenas eget pellentesque metus. Cras auctor mattis leo, nec consectetur dolor consequat in. Suspendisse mollis elit nisi, at imperdiet mauris pellentesque nec</p>\r\n', 'bn', 'index.png', '2018-03-14 15:11:46'),
(81, 5, 'nnnn', 'nnnn', '<p>This tutorial will show you how to upload an image and resize the image using Codeigniter. CodeIgniter&rsquo;s File Uploading Class permits files to be uploaded. You can set various preferences, restricting the type and size of the files.</p>\r\n\r\n<p>Uploading a file involves the following general process:</p>\r\n\r\n<p>An upload form is displayed, allowing a user to select a file and upload it.<br />\r\nWhen the form is submitted, the file is uploaded to the destination you specify.<br />\r\nAlong the way, the file is validated to make sure it is allowed to be uploaded based on the preferences you set.<br />\r\nOnce</p>\r\n', 'nash', 'index.png', '2018-03-16 08:48:43'),
(85, 5, 'first resize', 'first-resize', '<p>This tutorial will show you how to upload an image and resize the image using Codeigniter. CodeIgniter&rsquo;s File Uploading Class permits files to be uploaded. You can set various preferences, restricting the type and size of the files.</p>\r\n\r\n<p>Uploading a file involves the following general process:</p>\r\n\r\n<p>An upload form is displayed, allowing a user to select a file and upload it.<br />\r\nWhen the form is submitted, the file is uploaded to the destination you specify.<br />\r\nAlong the way, the file is validated to make sure it is allowed to be uploaded based on the preferences you set.</p>\r\n', 'nash', 'img804(1).jpg', '2018-03-16 09:05:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'Mark', 'mark@mail.com', 'Markdoe', '$2y$10$LeR2VuhHRKs.1Vc4q4roCusZ6zsJrNY9gqdY/daZCdJOdbgB11fWe', '2018-02-25 20:12:14'),
(21, 'ne', 'j@mail.com', 'ne', '$2y$10$j/zU5DtwSIG8wrRkjyrds.bbMk.Cg1xVS3CnmAqrfvzBPnjvUMbKO', '2018-02-27 08:45:25'),
(31, 'kk', 'kk@mail.com', 'kk', '$2y$10$B435NBwKnzCQe6aQZbWad.ZefnMqH7.pKTl/bYC4TliPXzcUqFQeG', '2018-02-27 19:13:42'),
(32, 'gg', 'g@mail.com', 'gg', '$2y$10$kB5G3nmk70.GL9qc4STLReTPAly7fEfJ4i4OsEnYRsrUZXF2PWuAG', '2018-02-27 20:20:23'),
(36, 'tt', 'ttt@mail.com', 'ttt', '$2y$10$Bb40kaZGzkU9yE4jpcY9AOZ.m/4sNdtyXp.MruE3aFPizMvVRheLS', '2018-02-27 20:47:23'),
(37, 'bn', 'b@mail.com', 'bn', '$2y$10$iUk/ziYD46lwmNU1RdlcP.Psyof9UXFddquNteyBXtfIezwyukOK.', '2018-02-27 21:16:32'),
(38, 'mark', 'joe@mail.com', 'mark', '$2y$10$1Dd3It2LrYYsCSAh/JV1Y.1McR6P2SF/d/.gJLqqIugrCkGjLpZ6q', '2018-02-27 21:17:41'),
(39, 'ff', 'ff@mail.com', 'ff', '$2y$10$SEjrAyQEtbeMN41h7Ljo9udsNNLSM/iyoYZE61oJlS4t06Rlv6Zz2', '2018-02-28 11:17:46'),
(40, 'Martha', 'mas@mail.com', 'martha', '$2y$10$bpy/ptpWpRKnxPLBTaeRqevhEi0fz3arn4G0H5ZqcDM3F5wobOZ.S', '2018-03-01 11:14:18'),
(41, 'Wheldon', 'w@mail.com', 'wheldon', '$2y$10$ZN71ymqbwhG2uG7rlmQKq.EiZqdjZbsQfdhMH0Ag7EZLrV1loynTC', '2018-03-01 11:16:33'),
(42, 'James', 'ja@mail.com', 'james', '$2y$10$IXiSR.RodSsTIexYHhMSHOzv0QRv40xBrufi1OqvRpoOcLPD/o33e', '2018-03-01 11:18:54'),
(43, 'vivian', 'v@mail.com', 'vivian', '$2y$10$D3y.2wAY34sp2AxrpA9C9upXK.VA7vsdmPeYg6NrEUD1pkTBjINom', '2018-03-01 11:21:21'),
(44, 'nash', 'nash@mail.com', 'nash', '$2y$10$6Xt6Q9pBOUWOReuXWmgDs.8QWyMxIrrl2kHnSQT0vi.ZBeE0B/oMq', '2018-03-02 08:23:38'),
(45, 'deno', 'd@mail.com', 'deno', '$2y$10$akfiOTBNVeRqo8LXNoEAfO8beC7ujBEzXlg41xKev8J2XXb4RItf6', '2018-03-02 18:39:58'),
(46, 'fas', 'fas@awsb.go.ke', 'fas', '$2y$10$M3HBVBqdm8BYx8e.7DI3W.eTH8/ZdwGFPpNOEwoW26NPRkPAzBC32', '2018-03-06 08:08:33'),
(47, 'daniel', 'daniel@awsb.go.ke', 'dan', '$2y$10$mqW9uoJ29vaYw13uuDAfOurT6ImYlfsHJMr0o64EHjKDptQ5uulYq', '2018-03-06 08:11:35'),
(48, 'rael', 'royaya@awsb.go.ke', 'rael', '$2y$10$dV1b08wfXgra/P5bqlgl0uP1TDQxqa7aOxFLCk2EJJWT8.9DuVdaS', '2018-03-06 08:30:41'),
(49, 'mark', 'mark@awsb.go.ke', 'maki', '$2y$10$UlZW0Q.0Yi3SUOx1zRrAj.JpnoOzUyEeiAAuetlAmbjUqQbPOebLu', '2018-03-06 12:34:24'),
(50, 'maki', 'maki@awsb.go.ke', 'mas', '$2y$10$5G1MBvQ3R3Bxp34E2SWVPOhsrC40meQlvXYpFlCZEewSvkRtfKDB6', '2018-03-06 12:36:28'),
(51, 'nas', 'nas@awsb.go.ke', 'nas', '$2y$10$lMeFGSFL/cz54QdQEVhj..6MNESKnoxLUngi1ELQ5YZL.nE80hWyy', '2018-03-06 12:40:52'),
(52, 'bg', 'bgea@awsb.go.ke', 'bg', '$2y$10$1GBf7kRUuL8rZLBXML7IL.o4vO4OlWsinbfjqJKzX7FBDr.ChYDMq', '2018-03-10 18:59:45'),
(53, 'bb', 'bbb@awsb.go.ke', 'bb', '$2y$10$UGx66ulB6ikx2Wcwsyu8NeYaiJQq4cXqaJsavclgG1qsYmT3xGbJ6', '2018-03-12 08:18:25'),
(55, 'hhh', 'hhh@awsb.go.ke', 'hhh', '$2y$10$QDef5WLU8X1J36.GShRqFeP.KHplAfWxNXw8Mrcb87MYFoyBZ/ae.', '2018-03-13 18:55:38'),
(56, 'fff', 'fff@awsb.go.ke', 'fff', '$2y$10$F.LYXCN64C45y.cc3C8c9uQABLPtXxqkzl1dd9X4XxJsvMjBnAUl2', '2018-03-13 18:57:01'),
(57, 'hhhh', 'hhhh@awsboard.go.ke', 'hhhh', '$2y$10$Ma6ae4RHbJWn5djVJSnlB.mxWkSuCmc1BLIs45Q2iK2hXSAKh8jYO', '2018-03-16 17:51:56'),
(58, '', '', 'ken', '$2y$10$z.06F2l7aw5aeFsHpoHbXOPqU2G2YvDP.dMQxr2NnYs6BZrdniqV2', '2018-05-06 05:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `users2`
--

CREATE TABLE `users2` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users2`
--

INSERT INTO `users2` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(3, 'ketri', '', '$2y$10$yfPeSZ88B/mQH.sl1tAx3uMMul81VdW3SrLfID6dD7ltOvlnK9CRm', '2018-05-06 08:20:04'),
(4, 'Tevin', '', '$2y$10$YGY1xo3IG16Lrr6KGJ.vSOUohm/URqfOQslvg/daXinRMKXixCbd2', '2018-05-06 08:47:01'),
(5, 'deno', 'deno@mail.com', '$2y$10$Ba4SFX/8L9HfRdBMAFTauuwYCQdnjceZKzEL0cF8S6MvVQ57m9Bw2', '2018-05-06 18:56:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users2`
--
ALTER TABLE `users2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `users2`
--
ALTER TABLE `users2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
