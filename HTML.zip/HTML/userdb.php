<?php
$con=mysqli_connect ("localhost","root","","user");
// check connection

//use predefined function mysql_select_db to call our database
if (mysqli_connect_errno())
{
	echo "Failed to connect to MySQL:" .mysqli_connect_error();
}
